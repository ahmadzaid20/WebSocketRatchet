<?php
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

require __DIR__ . '/vendor/autoload.php';

class Chat implements MessageComponentInterface {
    protected $clients;
    protected $rooms;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
        $this->rooms = [];  // Matrix to track users in each room
    }

    public function onOpen(ConnectionInterface $conn) {
        $querystring = $conn->httpRequest->getUri()->getQuery();
        parse_str($querystring, $queryParams);

        $username = $queryParams['username'] ?? 'Anonymous';
        $room = $queryParams['room'] ?? 'General';

        $conn->username = $username;
        $conn->room = $room;

        $this->clients->attach($conn);

        // Add user to room
        if (!isset($this->rooms[$room])) {
            $this->rooms[$room] = [];
        }
        $this->rooms[$room][$conn->resourceId] = $username;

        echo "New connection! ({$conn->resourceId}), Username: {$username}, Room: {$room}\n";

        // Send updated user list to all clients in the room
        $this->sendUsersInRoom($room);
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg, true);

        if ($data['action'] === 'checkMessages') {
            $this->sendSavedMessagesForRoom($from, $data['room']);
        } elseif ($data['action'] === 'typing' || $data['action'] === 'stopTyping') {
            foreach ($this->clients as $client) {
                if ($from !== $client && $client->room === $data['room']) {
                    $client->send($msg);
                }
            }
        } else {
            $numRecv = count($this->clients) - 1;
            echo sprintf('Connection %d sending message "%s" to %d other connection%s' . "\n"
                , $from->resourceId, $msg, $numRecv, $numRecv == 1 ? '' : 's');

            $messageWithConnectionInfo = [
                'username' => $from->username,
                'room' => $from->room,
                'message' => $data['message'],
                'timestamp' => date('Y-m-d H:i:s'),
                'action' => 'sendMessage'
            ];

            $messageToSend = json_encode($messageWithConnectionInfo);
            $this->saveMessageToFile($messageToSend, $data['room']);

            foreach ($this->clients as $client) {
                if ($from !== $client && $client->room === $data['room']) {
                    $client->send($messageToSend);
                }
            }
        }
    }

    public function onClose(ConnectionInterface $conn) {
        $this->clients->detach($conn);
        $room = $conn->room;

        // Remove user from room
        unset($this->rooms[$room][$conn->resourceId]);

        // If the room becomes empty, remove it.
        if (empty($this->rooms[$room])) {
            unset($this->rooms[$room]);
        }

        echo "Connection {$conn->resourceId} (Username: {$conn->username}, Room: {$conn->room}) has disconnected\n";

        // Send updated user list to all clients in the room
        $this->sendUsersInRoom($room);
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";
        $conn->close();
    }

    protected function saveMessageToFile($msg, $room) {
        $file = "chat_log_{$room}.txt";

        if (!file_exists($file)) {
            if (file_put_contents($file, '') === false) {
                echo "Error: Could not create file {$file}\n";
            } else {
                echo "File {$file} created successfully.\n";
            }
        }

        $currentContent = file_get_contents($file);
        if ($currentContent === false) {
            echo "Error: Could not read file {$file}\n";
        } else {
            $currentContent .= $msg . "\n";
            if (file_put_contents($file, $currentContent) === false) {
                echo "Error: Could not write to file {$file}\n";
            } else {
                echo "Message saved to {$file}\n";
            }
        }
    }

    protected function sendSavedMessagesForRoom(ConnectionInterface $conn, $room) {
        $file = "chat_log_{$room}.txt";
        if (file_exists($file)) {
            $messages = file($file, FILE_IGNORE_NEW_LINES);
            $parsedMessages = [];

            foreach ($messages as $message) {
                $messageData = json_decode($message, true);
                if ($messageData && isset($messageData['timestamp'])) {
                    $messageData['datetime'] = new DateTime($messageData['timestamp']);
                    $parsedMessages[] = $messageData;
                }
            }

            usort($parsedMessages, function($a, $b) {
                return $a['datetime'] <=> $b['datetime'];
            });

            foreach ($parsedMessages as $message) {
                unset($message['datetime']);
                $conn->send(json_encode($message));
            }
        }
    }

    protected function sendUsersInRoom($room) {
        if (isset($this->rooms[$room])) {
            $users = array_values($this->rooms[$room]);
            $data = [
                'action' => 'updateUsers',
                'users' => $users
            ];

            foreach ($this->clients as $client) {
                if ($client->room === $room) {
                    $client->send(json_encode($data));
                }
            }
        }
    }
}

$server = \Ratchet\Server\IoServer::factory(
    new \Ratchet\Http\HttpServer(
        new \Ratchet\WebSocket\WsServer(
            new Chat()
        )
    ),
    8080
);

$server->run();
