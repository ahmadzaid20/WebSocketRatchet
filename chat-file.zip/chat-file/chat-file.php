<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        #messages {
            width: 90%;
            height: 300px;
            overflow-y: scroll;
            padding: 10px;
        }
        .message {
            padding: 10px;
            margin: 5px;
            border-radius: 10px;
            max-width: 70%;
            word-wrap: break-word;
        }
        .message.you {
            background-color: #d4edda;
            text-align: left;
            margin-left: 0;
            border-radius: 10px 10px 10px 0px;
        }
        .message.other {
            background-color: #f1f1f1;
            text-align: right;
            margin-left: auto;
            border-radius: 10px 0px 10px 10px;
        }
        .message .meta {
            font-size: 0.8em;
            color: #555;
        }
        .message .meta strong {
            font-weight: bold;
        }
        #messageInput, #usernameInput, #roomInput {
            width: calc(100% - 120px);
            padding: 10px;
            margin: 10px auto;
            margin-right: 10px;
            border: 1px solid #ccc;
        }
        #usernameInput, #roomInput {
            width: calc(100% - 120px);
        }
        #sendBtn, #saveUsernameBtn {
            padding: 10px 20px;
            border: none;
            background-color: #007bff;
            color: white;
            cursor: pointer;
        }
        #sendBtn:hover, #saveUsernameBtn:hover {
            background-color: #0056b3;
        }
        .date-divider {
            display: flex;
            align-items: center;
            text-align: center;
            margin: 20px 0;
            position: relative;
        }
        .date-divider span {
            background-color: #f1f1f1;
            padding: 0 10px;
            color: #555;
            font-size: 0.9em;
            font-weight: bold;
        }
        .date-divider::before {
            content: '';
            flex: 1;
            border-bottom: 1px solid #ccc;
            margin-right: 10px;
        }
        .date-divider::after {
            content: '';
            flex: 1;
            border-bottom: 1px solid #ccc;
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <h1>Chat</h1>
    <input type="text" id="usernameInput" placeholder="Enter your name">
    <input type="text" id="roomInput" placeholder="Enter room name">
    <button id="saveUsernameBtn">Save Username</button>
    <div id="messages" data-last-date=""></div>
    <input type="text" id="messageInput" placeholder="Enter your message" disabled>
    <button id="sendBtn" disabled>Send</button>

    <script>
        let username = null;
        let room = null;
        let socket = null;

        document.getElementById('saveUsernameBtn').addEventListener('click', function () {
            const usernameInput = document.getElementById('usernameInput').value;
            const roomInput = document.getElementById('roomInput').value;
            if (usernameInput.trim() !== "" && roomInput.trim() !== "") {
                username = usernameInput;
                room = roomInput;
                alert(`Username saved as ${username} in room ${room}`);

                // Open a WebSocket connection passing the room name and username.
                socket = new WebSocket(`ws://192.168.0.6:8080?username=${encodeURIComponent(username)}&room=${encodeURIComponent(room)}`);

                socket.addEventListener('open', function (event) {
                    console.log(`Connected to the WebSocket server as ${username} in room ${room}`);

                    // Submit a request for archived messages
                    socket.send(JSON.stringify({ action: 'checkMessages', room: room }));
                });

                socket.addEventListener('message', function (event) {
                    const messagesDiv = document.getElementById('messages');
                    const newMessage = document.createElement('div');
                    const receivedData = JSON.parse(event.data);

                    // Set date and time
                    const timestamp = new Date(receivedData.timestamp);
                    const timeString = timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                    const dateString = timestamp.toLocaleDateString();

                    // Check if this is the first date or if it is different from the last message.
                    const lastMessageDate = messagesDiv.getAttribute('data-last-date');
                    if (lastMessageDate !== dateString) {
                        const dateDivider = document.createElement('div');
                        dateDivider.classList.add('date-divider');
                        dateDivider.innerHTML = `<span>${dateString}</span>`;
                        messagesDiv.appendChild(dateDivider);

                        // Update last viewed date
                        messagesDiv.setAttribute('data-last-date', dateString);
                    }

                    // Check if the current user sent the message
                    const displayName = receivedData.username === username ? 'You' : receivedData.username;

                    newMessage.classList.add('message', receivedData.username === username ? 'you' : 'other');
                    newMessage.innerHTML = `<div class="meta"><strong>${displayName}</strong> : ${timeString}</div>${receivedData.message}`;
                    messagesDiv.appendChild(newMessage);
                    messagesDiv.scrollTop = messagesDiv.scrollHeight;
                });

                // Enable message input and send button
                document.getElementById('messageInput').disabled = false;
                document.getElementById('sendBtn').disabled = false;
            } else {
                alert("Please enter a valid username and room name.");
            }
        });

        document.getElementById('sendBtn').addEventListener('click', function () {
            const messageInput = document.getElementById('messageInput').value;

            if (messageInput.trim() === "") {
                return;
            }

            // Time format to remove seconds
            const timestamp = new Date().toISOString(); // Save the full ISO string including date and time

            const messageData = {
                username: username,
                room: room,
                message: messageInput,
                timestamp: timestamp
            };

            socket.send(JSON.stringify(messageData));

            const messagesDiv = document.getElementById('messages');
            const newMessage = document.createElement('div');
            const timeString = new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            newMessage.classList.add('message', 'you');
            newMessage.innerHTML = `<div class="meta"><strong>You</strong> : ${timeString}</div>${messageInput}`;
            messagesDiv.appendChild(newMessage);
            messagesDiv.scrollTop = messagesDiv.scrollHeight;

            document.getElementById('messageInput').value = '';
        });
    </script>
</body>
</html>
