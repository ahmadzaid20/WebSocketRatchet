<?php
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

require __DIR__ . '/vendor/autoload.php';

class Chat implements MessageComponentInterface {
    protected $clients;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
    }

    public function onOpen(ConnectionInterface $conn) {
        // Extract username and room name from contact query
        $querystring = $conn->httpRequest->getUri()->getQuery();
        parse_str($querystring, $queryParams);

        $username = $queryParams['username'] ?? 'Anonymous';
        $room = $queryParams['room'] ?? 'General';

        // Store contact information
        $conn->username = $username;
        $conn->room = $room;

        $this->clients->attach($conn);

        // Display contact number with room name and username
        echo "New connection! ({$conn->resourceId}), Username: {$username}, Room: {$room}\n";
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg, true);

        if (isset($data['action']) && $data['action'] === 'checkMessages') {
            // Check and send saved messages for the selected room.
            $this->sendSavedMessagesForRoom($from, $data['room']);
        } else {
            $numRecv = count($this->clients) - 1;
            echo sprintf('Connection %d sending message "%s" to %d other connection%s' . "\n"
                , $from->resourceId, $msg, $numRecv, $numRecv == 1 ? '' : 's');

            // Save the message in a room text file.
            $this->saveMessageToFile($msg, $data['room']);

            // Send message to all connected users in the same room
            foreach ($this->clients as $client) {
                if ($from !== $client && $client->room === $data['room']) {
                    $client->send($msg);
                }
            }
        }
    }

    public function onClose(ConnectionInterface $conn) {
        $this->clients->detach($conn);
        echo "Connection {$conn->resourceId} (Username: {$conn->username}, Room: {$conn->room}) has disconnected\n";
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";
        $conn->close();
    }

    protected function saveMessageToFile($msg, $room) {
        $file = "chat_log_{$room}.txt";  // File name includes room name.
    
        // If the file does not exist, create it.
        if (!file_exists($file)) {
            if (file_put_contents($file, '') === false) {
                echo "Error: Could not create file {$file}\n";
            } else {
                echo "File {$file} created successfully.\n";
            }
        }
    
        $currentContent = file_get_contents($file);
        if ($currentContent === false) {
            echo "Error: Could not read file {$file}\n";
        } else {
            $currentContent .= $msg . "\n";  // Add new message
            if (file_put_contents($file, $currentContent) === false) {
                echo "Error: Could not write to file {$file}\n";
            } else {
                echo "Message saved to {$file}\n";
            }
        }
    }
    
    protected function sendSavedMessagesForRoom(ConnectionInterface $conn, $room) {
        $file = "chat_log_{$room}.txt";  // File name includes room name.
        if (file_exists($file)) {
            $messages = file($file, FILE_IGNORE_NEW_LINES);
            $parsedMessages = [];

            // Data analysis to extract timestamp and convert it to JSON objects
            foreach ($messages as $message) {
                $messageData = json_decode($message, true);
                if ($messageData && isset($messageData['timestamp'])) {
                    // Convert timestamp to DateTime object
                    $messageData['datetime'] = new DateTime($messageData['timestamp']);
                    $parsedMessages[] = $messageData;
                }
            }

            // Sort messages by time stamp from oldest to newest
            usort($parsedMessages, function($a, $b) {
                return $a['datetime'] <=> $b['datetime'];
            });

            // Send messages to the client in chronological order
            foreach ($parsedMessages as $message) {
                unset($message['datetime']); // Delete datetime field after sorting
                $conn->send(json_encode($message));
            }
        }
    }
}

$server = \Ratchet\Server\IoServer::factory(
    new \Ratchet\Http\HttpServer(
        new \Ratchet\WebSocket\WsServer(
            new Chat()
        )
    ),
    8080
);

$server->run();
