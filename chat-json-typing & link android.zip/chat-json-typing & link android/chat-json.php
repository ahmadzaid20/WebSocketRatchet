<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        #messages {
            width: 90%;
            height: 300px;
            overflow-y: scroll;
            padding: 10px;
            border: 1px solid #ccc;
        }
        .message {
            padding: 10px;
            margin: 5px;
            border-radius: 10px;
            max-width: 70%;
            word-wrap: break-word;
        }
        .message.you {
            background-color: #d4edda;
            text-align: left;
            margin-left: 0;
            border-radius: 10px 10px 10px 0px;
        }
        .message.other {
            background-color: #f1f1f1;
            text-align: right;
            margin-left: auto;
            border-radius: 10px 0px 10px 10px;
        }
        .message .meta {
            font-size: 0.8em;
            color: #555;
        }
        .message .meta strong {
            font-weight: bold;
        }
        #messageInput, #usernameInput, #roomInput, #userIdInput {
            width: calc(100% - 120px);
            padding: 10px;
            margin: 10px auto;
            margin-right: 10px;
            border: 1px solid #ccc;
        }
        #sendBtn, #saveUsernameBtn {
            padding: 10px 20px;
            border: none;
            background-color: #007bff;
            color: white;
            cursor: pointer;
        }
        #sendBtn:hover, #saveUsernameBtn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h1>Chat</h1>
    <input type="text" id="usernameInput" placeholder="Enter your name">
    <input type="text" id="roomInput" placeholder="Enter room name">
    <input type="text" id="userIdInput" placeholder="Enter your User ID"> <!-- إدخال معرف المستخدم -->
    <button id="saveUsernameBtn">Save Username</button>
    <ul id="users"></ul> <!-- User List -->
    <div id="messages" data-last-date=""></div>
    <div id="typingIndicator"></div>
    <input type="text" id="messageInput" placeholder="Enter your message" disabled>
    <button id="sendBtn" disabled>Send</button>

    <script>
        let username = null;
        let room = null;
        let userId = null;  // متغير لتخزين معرف المستخدم
        let socket = null;
        let typingTimeout;
        const TYPING_DELAY = 3000;

        document.getElementById('saveUsernameBtn').addEventListener('click', function () {
            const usernameInput = document.getElementById('usernameInput').value;
            const roomInput = document.getElementById('roomInput').value;
            const userIdInput = document.getElementById('userIdInput').value;  // استلام معرف المستخدم

            if (usernameInput.trim() !== "" && roomInput.trim() !== "" && userIdInput.trim() !== "") {
                username = usernameInput;
                room = roomInput;
                userId = userIdInput;  // تخزين معرف المستخدم
                alert(`Username: ${username}, Room: ${room}, User ID: ${userId}`);

                // إنشاء اتصال WebSocket مع تمرير معرف المستخدم
                socket = new WebSocket(`ws://192.168.0.6:8080?username=${encodeURIComponent(username)}&room=${encodeURIComponent(room)}&userId=${encodeURIComponent(userId)}`);

                socket.addEventListener('open', function (event) {
                    console.log(`Connected to the WebSocket server as ${username} in room ${room}, User ID: ${userId}`);
                });

                socket.addEventListener('message', function (event) {
    const receivedData = JSON.parse(event.data);

    if (receivedData.action === 'sendMessage') {
        // عرض الرسالة المستلمة من السيرفر
        displayMessage(receivedData);

        // إرسال إشعار بأن الرسالة تم استلامها
        socket.send(JSON.stringify({
            action: 'messageReceived',
            messageId: receivedData.messageId
        }));
    } else if (receivedData.action === 'updateUsers') {
        // تحديث قائمة المستخدمين في الغرفة
        document.getElementById('users').textContent = receivedData.users.join(', ');
    } else if (receivedData.action === 'updateMessageStatus') {
        // تحديث حالة الرسائل
        updateMessageStatus(receivedData);
    } else if (receivedData.action === 'typing') {
        // التعامل مع حالة الكتابة
        document.getElementById('typingIndicator').textContent = receivedData.username + ' is typing...';
    } else if (receivedData.action === 'stopTyping') {
        // إخفاء حالة الكتابة عند التوقف
        document.getElementById('typingIndicator').textContent = '';
    }
});



                document.getElementById('messageInput').disabled = false;
                document.getElementById('sendBtn').disabled = false;
            } else {
                alert("Please enter valid username, room name, and User ID.");
            }
        });

        document.getElementById('sendBtn').addEventListener('click', function () {
    const messageInput = document.getElementById('messageInput').value;

    if (messageInput.trim() === "") {
        return;
    }

    const timestamp = new Date().toISOString();

    const messageData = {
        username: username,
        room: room,
        userId: userId,
        message: messageInput,
        timestamp: timestamp,
        action: 'sendMessage'
    };

    // إرسال الرسالة إلى السيرفر عبر WebSocket
    socket.send(JSON.stringify(messageData));

    // ** لا تقم بعرض الرسالة هنا **
    // سيتم عرض الرسالة عند استلام الرد من السيرفر

    document.getElementById('messageInput').value = ''; // إعادة تعيين حقل الإدخال
});


        document.getElementById('messageInput').addEventListener('input', function () {
            socket.send(JSON.stringify({ action: 'typing' }));

            clearTimeout(typingTimeout);
            typingTimeout = setTimeout(function () {
                socket.send(JSON.stringify({ action: 'stopTyping' }));
            }, TYPING_DELAY);
        });


        function displayMessage(messageData) {
    const messagesDiv = document.getElementById('messages');
    const newMessage = document.createElement('div');
    const timestamp = new Date(messageData.timestamp);
    const timeString = timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    newMessage.classList.add('message', messageData.username === username ? 'you' : 'other');
    newMessage.innerHTML = `<div class="meta"><strong>${messageData.username === username ? 'You' : messageData.username}</strong>: ${timeString}</div>${messageData.message}`;
    messagesDiv.appendChild(newMessage);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

    </script>
</body>
</html>
