<?php
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

require __DIR__ . '/vendor/autoload.php';

class Chat implements MessageComponentInterface {
    protected $clients;
    protected $rooms;
    protected $messages;  // لتخزين الرسائل وحالاتها

    public function __construct() {
        $this->clients = new \SplObjectStorage;
        $this->rooms = [];
    }

    // تحميل الرسائل المحفوظة من ملف JSON بناءً على Room ID
    protected function loadMessagesFromFile($roomId) {
        $filePath = __DIR__ . "/rooms/room_$roomId.json";
        
        // التحقق إذا كان الملف موجودًا وقراءة الرسائل
        if (file_exists($filePath)) {
            return json_decode(file_get_contents($filePath), true) ?? [];
        }

        return []; // إذا لم يكن هناك ملف للغرفة، إرجاع قائمة فارغة
    }

    // حفظ الرسائل في ملف JSON بناءً على Room ID
    protected function saveMessagesToFile($roomId, $messages) {
        $filePath = __DIR__ . "/rooms/room_$roomId.json"; // تخزين الملف في مجلد "rooms"
        
        // التأكد من وجود المجلد
        if (!is_dir(__DIR__ . '/rooms')) {
            mkdir(__DIR__ . '/rooms', 0777, true);
        }

        // حفظ الرسائل في الملف
        file_put_contents($filePath, json_encode($messages, JSON_PRETTY_PRINT));
    }

    public function onOpen(ConnectionInterface $conn) {
        // استلام بيانات الاتصال عبر query string
        $querystring = $conn->httpRequest->getUri()->getQuery();
        parse_str($querystring, $queryParams);

        // قراءة بيانات الغرفة والمستخدم
        $username = $queryParams['username'] ?? 'Anonymous';
        $room = $queryParams['room'] ?? 'General';
        $userId = $queryParams['userId'] ?? uniqid();

        // ربط بيانات الاتصال
        $conn->username = $username;
        $conn->room = $room;
        $conn->userId = $userId;

        // إضافة الاتصال إلى قائمة العملاء
        $this->clients->attach($conn);

        // إعداد الغرفة إذا لم تكن موجودة
        if (!isset($this->rooms[$room])) {
            $this->rooms[$room] = [];
        }
        $this->rooms[$room][$conn->resourceId] = ['username' => $username, 'userId' => $userId];

        echo "New connection! ({$conn->resourceId}), Username: {$username}, Room: {$room}, UserId: {$userId}\n";

        // إرسال المستخدمين في الغرفة
        $this->sendUsersInRoom($room);

        // إرسال الرسائل المحفوظة
        $this->sendSavedMessagesForRoom($conn, $room);
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg, true);

        if ($data['action'] === 'sendMessage') {
            $this->handleSendMessage($from, $data);
        } elseif ($data['action'] === 'typing') {
            $this->notifyTypingStatus($from, true);
        } elseif ($data['action'] === 'stopTyping') {
            $this->notifyTypingStatus($from, false);
        } elseif ($data['action'] === 'messageReceived') {
            $this->updateMessageStatus($data['messageId'], 'received', $from->userId);
        } elseif ($data['action'] === 'messageSeen') {
            $this->updateMessageStatus($data['messageId'], 'seen', $from->userId);
        }
    }

    protected function handleSendMessage(ConnectionInterface $from, $data) {
        $username = $from->username ?? 'Anonymous';
        $room = $from->room ?? 'General';
        $userId = $from->userId;
        $messageId = uniqid();
        $message = $data['message'] ?? '';
    
        echo "$username (UserId: $userId) in room $room: $message\n";
    
        // إنشاء بيانات الرسالة التي سيتم إرسالها
        $messageWithConnectionInfo = [
            'messageId' => $messageId,
            'username' => $username,
            'userId' => $userId,
            'room' => $room,
            'message' => $message,
            'timestamp' => date('Y-m-d H:i:s'),
            'action' => 'sendMessage',
            'status' => ['sent' => [$userId], 'received' => [], 'seen' => []]
        ];

        // تحميل الرسائل السابقة من الملف
        $messages = $this->loadMessagesFromFile($room);

        // إضافة الرسالة الجديدة
        $messages[] = $messageWithConnectionInfo;

        // حفظ الرسائل المحدثة في الملف
        $this->saveMessagesToFile($room, $messages);
    
        $messageToSend = json_encode($messageWithConnectionInfo);
    
        // إرسال الرسالة لجميع المستخدمين في نفس الغرفة
        foreach ($this->clients as $client) {
            if ($client->room === $room) {
                $client->send($messageToSend); // إرسال الرسالة لجميع المستخدمين في الغرفة
            }
        }
    }

    protected function notifyTypingStatus(ConnectionInterface $from, $isTyping) {
        $room = $from->room;
        $data = [
            'action' => $isTyping ? 'typing' : 'stopTyping',
            'username' => $from->username
        ];

        foreach ($this->clients as $client) {
            if ($client !== $from && $client->room === $room) { // التأكد من عدم إرسال حالة الكتابة إلى المستخدم نفسه
                $client->send(json_encode($data));
            }
        }
    }

    protected function updateMessageStatus($messageId, $status, $userId) {
        $room = null;
        foreach ($this->rooms as $roomId => $clients) {
            if (isset($clients[$userId])) {
                $room = $roomId;
                break;
            }
        }
        if ($room === null) return;

        // تحميل الرسائل من الملف
        $messages = $this->loadMessagesFromFile($room);

        foreach ($messages as &$message) {
            if ($message['messageId'] === $messageId) {
                if (!in_array($userId, $message['status'][$status])) {
                    $message['status'][$status][] = $userId;
                }
                break;
            }
        }

        // حفظ التحديثات إلى الملف
        $this->saveMessagesToFile($room, $messages);

        // إرسال التحديث للمستخدمين
        $this->notifyUsersMessageStatus($messageId, $status, $room);
    }

    protected function notifyUsersMessageStatus($messageId, $status, $room) {
        $data = [
            'action' => 'updateMessageStatus',
            'messageId' => $messageId,
            'status' => $status
        ];

        foreach ($this->clients as $client) {
            if ($client->room === $room) {
                $client->send(json_encode($data));
            }
        }
    }

    public function onClose(ConnectionInterface $conn) {
        $this->clients->detach($conn);
        $room = $conn->room;

        unset($this->rooms[$room][$conn->resourceId]);

        if (empty($this->rooms[$room])) {
            unset($this->rooms[$room]);
        }

        echo "Connection {$conn->resourceId} (Username: {$conn->username}, Room: {$conn->room}) has disconnected\n";

        $this->sendUsersInRoom($room);
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";
        $conn->close();
    }

    protected function sendUsersInRoom($room) {
        if (isset($this->rooms[$room])) {
            $usernames = array_map(function($user) {
                return $user['username'];
            }, array_values($this->rooms[$room]));

            $data = [
                'action' => 'updateUsers',
                'users' => $usernames
            ];

            foreach ($this->clients as $client) {
                if ($client->room === $room) {
                    $client->send(json_encode($data));
                }
            }
        }
    }

    protected function sendSavedMessagesForRoom(ConnectionInterface $conn, $room) {
        $messages = $this->loadMessagesFromFile($room);

        foreach ($messages as $message) {
            $conn->send(json_encode($message));
        }
    }
}

$server = \Ratchet\Server\IoServer::factory(
    new \Ratchet\Http\HttpServer(
        new \Ratchet\WebSocket\WsServer(
            new Chat()
        )
    ),
    8080
);

$server->run();
