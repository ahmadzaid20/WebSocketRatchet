<?php
require_once 'secrets.php'; // Include database connection setup file

function executeQuery($query, $params = []) {
    global $mysqli; // Using database connection from secrets.php file
    $stmt = $mysqli->prepare($query);
    if ($stmt === false) {
        die('Prepare failed: ' . $mysqli->error);
    }

    if (!empty($params)) {
        $types = str_repeat('s', count($params)); // Assuming all variables are of type string, this can be customized as needed.
        $stmt->bind_param($types, ...$params);
    }

    if (!$stmt->execute()) {
        die('Execute failed: ' . $stmt->error);
    }

    return $stmt;
}

function fetchAll($query, $params = []) {
    $stmt = executeQuery($query, $params);
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function fetchSingle($query, $params = []) {
    $stmt = executeQuery($query, $params);
    return $stmt->get_result()->fetch_assoc();
}
?>
