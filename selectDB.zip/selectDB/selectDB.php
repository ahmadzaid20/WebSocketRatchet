<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Data Display</title>
</head>
<body>
    <h1>Live Data from Database</h1>

    <label for="dataSelect">Select Data:</label>
    <select id="dataSelect">
        <option value="">Select an option</option>
    </select>

    <br><br>

    <label for="dataInput">Selected Data:</label>
    <input type="text" id="dataInput">

    <br><br>

    <button id="addBtn">Add New Data</button>
    <button id="deleteBtn">Delete Selected Data</button>
    <button id="updateBtn">Update Data</button>

    <div id="dataDisplay"></div>

    <script>
        const socket = new WebSocket('ws://localhost:8080');

        socket.addEventListener('open', function (event) {
            console.log('Connected to the WebSocket server');
        });

        socket.addEventListener('message', function (event) {
            const dataDisplayDiv = document.getElementById('dataDisplay');
            const dataSelect = document.getElementById('dataSelect');
            let receivedData;

            try {
                receivedData = JSON.parse(event.data);
            } catch (e) {
                console.error('Error parsing JSON:', e);
                return;
            }

            // Make sure the data is in an array
            if (!Array.isArray(receivedData)) {
                console.error('Received data is not an array:', receivedData);
                return;
            }

            // Empty the drop-down list of old options
            dataSelect.innerHTML = '<option value="">Select an option</option>';

            // Adding data to the drop-down list
            receivedData.forEach(function(item) {
                const option = document.createElement('option');
                option.value = item.id;
                option.textContent = item.name;
                dataSelect.appendChild(option);
            });

            // Update Data Display
            dataDisplayDiv.innerHTML = ''; // Dump the old data view
            const newData = document.createElement('div');
            newData.textContent = 'Data: ' + JSON.stringify(receivedData);
            dataDisplayDiv.appendChild(newData);
        });

        // When selecting an item from the drop-down list
        document.getElementById('dataSelect').addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            document.getElementById('dataInput').value = selectedOption.textContent;
        });

        // Adding a new item to the database
        document.getElementById('addBtn').addEventListener('click', function() {
            const newValue = document.getElementById('dataInput').value;

            if (newValue.trim() === "") {
                alert("Please enter a value to add.");
                return;
            }

            // Send the add request to the server via WebSocket
            const addMessage = JSON.stringify({
                action: 'add',
                name: newValue
            });

            socket.send(addMessage);
        });

        // Delete the selected item from the database
        document.getElementById('deleteBtn').addEventListener('click', function() {
            const selectedOption = document.getElementById('dataSelect').value;

            if (selectedOption === "") {
                alert("Please select an item to delete.");
                return;
            }

            // Send the delete request to the server via WebSocket
            const deleteMessage = JSON.stringify({
                action: 'delete',
                id: selectedOption
            });

            socket.send(deleteMessage);
        });

        // Updating data in the database
        document.getElementById('updateBtn').addEventListener('click', function() {
            const selectedOption = document.getElementById('dataSelect').value;
            const updatedValue = document.getElementById('dataInput').value;

            if (selectedOption === "") {
                alert("Please select an item to update.");
                return;
            }

            // Send the update to the server via WebSocket
            const updateMessage = JSON.stringify({
                action: 'update',
                id: selectedOption,
                name: updatedValue
            });

            socket.send(updateMessage);
        });
    </script>
</body>
</html>