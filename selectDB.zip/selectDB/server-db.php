<?php
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

require __DIR__ . '/vendor/autoload.php';
require 'db_config.php'; // Include database setup file

class DataUpdate implements MessageComponentInterface {
    protected $clients;
    protected $mysqli;

    public function __construct($mysqli) {
        $this->clients = new \SplObjectStorage;
        $this->mysqli = $mysqli;
    }

    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
        echo "New connection! ({$conn->resourceId})\n";

        // Send data on new connection
        $this->sendData($conn);
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg, true);
        $operationSuccess = false;

        if (isset($data['action'])) {
            switch ($data['action']) {
                case 'add':
                    if (isset($data['name'])) {
                        $stmt = executeQuery("INSERT INTO user (name) VALUES (?)", [$data['name']]);
                        $operationSuccess = ($stmt->affected_rows > 0);
                    }
                    break;

                case 'delete':
                    if (isset($data['id'])) {
                        $stmt = executeQuery("DELETE FROM user WHERE id = ?", [$data['id']]);
                        $operationSuccess = ($stmt->affected_rows > 0);
                    }
                    break;

                case 'update':
                    if (isset($data['id']) && isset($data['name'])) {
                        $stmt = executeQuery("UPDATE user SET name = ? WHERE id = ?", [$data['name'], $data['id']]);
                        $operationSuccess = ($stmt->affected_rows > 0);
                    }
                    break;
            }

            // Send updates if the process is successful.
            if ($operationSuccess) {
                $this->broadcastData();
            }
        }
    }

    public function onClose(ConnectionInterface $conn) {
        $this->clients->detach($conn);
        echo "Connection {$conn->resourceId} has disconnected\n";
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";
        $conn->close();
    }

    protected function sendData(ConnectionInterface $conn) {
        $data = fetchAll("SELECT * FROM user");
        $conn->send(json_encode($data));
    }

    protected function broadcastData() {
        $data = fetchAll("SELECT * FROM user");
        foreach ($this->clients as $client) {
            $client->send(json_encode($data));
        }
    }
}

$app = new DataUpdate($mysqli);

$server = \Ratchet\Server\IoServer::factory(
    new \Ratchet\Http\HttpServer(
        new \Ratchet\WebSocket\WsServer(
            $app
        )
    ),
    8080
);

$server->run();
?>
