<?php

class DataUpdate {
    private $db;
    protected $dbConnection;

    public function __construct($dbConnection) {
        $this->dbConnection = $dbConnection;
        $this->db = $dbConnection;
    }

    public function selectNotifications($user_id) {
        $query = "SELECT id, title, message, url, is_received, is_opened FROM notifications WHERE user_id = :user_id";
        $stmt = $this->dbConnection->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function markNotificationAsReceived($notification_id) {
        $query = "UPDATE notifications SET is_received = 1 WHERE id = :id";
        $stmt = $this->dbConnection->prepare($query);
        $stmt->bindParam(':id', $notification_id);
        $stmt->execute();
    }

    public function markNotificationAsSent($notification_id) {
        $query = "UPDATE notifications SET is_sent = 1 WHERE id = :id";
        $stmt = $this->dbConnection->prepare($query);
        $stmt->bindParam(':id', $notification_id);
        $stmt->execute();
    }

    public function addNotification($user_id, $title, $message, $url) {
        $stmt = $this->db->prepare("
            INSERT INTO notifications (user_id, title, message, url, is_received, is_opened) 
            VALUES (:user_id, :title, :message, :url, 0, 0)
        ");
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':message', $message);
        $stmt->bindParam(':url', $url);
        $stmt->execute();
    
        // Returns the new notification ID
        return $this->db->lastInsertId();
    }
}
