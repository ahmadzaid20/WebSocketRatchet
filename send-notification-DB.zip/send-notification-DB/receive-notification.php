<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receive Notifications</title>
</head>
<body>
    <h1>Notifications</h1>

    <label for="userIdInput">Enter User ID:</label>
    <input type="text" id="userIdInput" placeholder="Enter your User ID">
    <button id="connectBtn">Connect</button>

    <div id="notificationsContainer"></div>

    <script>
        let socket;

        // Function to request notification permission
        function requestNotificationPermission() {
            if (Notification.permission === 'default') {
                Notification.requestPermission().then(permission => {
                    if (permission === 'granted') {
                        console.log('Notification permission granted.');
                    } else {
                        console.log('Notification permission denied.');
                    }
                });
            }
        }

        // Show desktop notification
        function showDesktopNotification(title, message, url) {
            if (Notification.permission === 'granted') {
                const notification = new Notification(title, { 
                    body: message,
                    icon: 'path/to/icon.png' // You can set the icon path here if you want to include an icon.
                });

                notification.onclick = function(event) {
                    event.preventDefault(); // Prevents the notification window from opening automatically.
                    window.open(url, '_blank'); // Opens the selected page in a new window.
                };
            } else {
                console.log('Notification permission is not granted.');
            }
        }

        // Connect to the WebSocket server
        document.getElementById('connectBtn').addEventListener('click', function() {
            const userId = document.getElementById('userIdInput').value;

            if (userId.trim() === "") {
                alert("Please enter your User ID.");
                return;
            }

            // Open a WebSocket connection with user_id as a query parameter
            socket = new WebSocket('ws://192.168.0.6:8080?user_id=' + encodeURIComponent(userId));

            socket.addEventListener('open', function(event) {
                console.log('Connected to the WebSocket server');
                requestNotificationPermission();
            });

            socket.addEventListener('message', function(event) {
    let receivedData;

    try {
        receivedData = JSON.parse(event.data);
    } catch (e) {
        console.error('Error parsing JSON:', e);
        return;
    }

    if (receivedData.type === 'new_notification') {
        // Display the notification in the browser
        displayNotification(receivedData.title, receivedData.message);
        // Display a notification on the desktop
        showDesktopNotification(receivedData.title, receivedData.message, receivedData.url);

        // Send confirmation of receipt to the server
        socket.send(JSON.stringify({
            action: 'confirm_receipt',
            notification_id: receivedData.id
        }));
    } else if (receivedData.type === 'notification') {
        // View all previous notifications when connected
        displayNotification(receivedData.title, receivedData.message);
    }
});


            socket.addEventListener('close', function(event) {
                console.log('Disconnected from the WebSocket server');
            });

            socket.addEventListener('error', function(event) {
                console.error('WebSocket error:', event);
            });
        });

        function displayNotification(title, message) {
            const notificationsContainer = document.getElementById('notificationsContainer');
            const notificationDiv = document.createElement('div');

            notificationDiv.innerHTML = `<h3>${title}</h3><p>${message}</p>`;
            notificationDiv.style.border = "1px solid #000";
            notificationDiv.style.padding = "10px";
            notificationDiv.style.marginBottom = "10px";

            notificationsContainer.appendChild(notificationDiv);
        }
    </script>
</body>
</html>
