<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Notification</title>
</head>
<body>
    <h1>Send Notification</h1>

    <label for="userId">User ID:</label>
    <input type="text" id="userId" placeholder="Enter user ID">

    <br><br>

    <label for="notificationTitle">Title:</label>
    <input type="text" id="notificationTitle" placeholder="Enter notification title">

    <br><br>

    <label for="notificationMessage">Message:</label>
    <textarea id="notificationMessage" placeholder="Enter notification message"></textarea>

    <br><br>

    <label for="notificationUrl">URL:</label>
    <input type="text" id="notificationUrl" placeholder="Enter notification URL">

    <br><br>

    <button id="sendNotificationBtn">Send Notification</button>

    <script>
        const socket = new WebSocket('ws://192.168.0.6:8080');

        socket.addEventListener('open', function (event) {
            document.getElementById('sendNotificationBtn').addEventListener('click', function() {
                const userId = document.getElementById('userId').value;
                const title = document.getElementById('notificationTitle').value;
                const message = document.getElementById('notificationMessage').value;
                const url = document.getElementById('notificationUrl').value;

                if (userId.trim() === "" || title.trim() === "" || message.trim() === "" || url.trim() === "") {
                    alert("Please enter user ID, title, message, and URL.");
                    return;
                }

                const notification = {
                    action: 'notify',
                    user_id: userId,
                    title: title,
                    message: message,
                    url: url
                };

                socket.send(JSON.stringify(notification));
                alert("Notification sent!");
            });
        });

        socket.addEventListener('error', function (event) {
            console.error('WebSocket error:', event);
        });
    </script>
</body>
</html>
