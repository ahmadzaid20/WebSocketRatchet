<?php

require 'vendor/autoload.php';
require 'DataUpdate.php';

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;

class NotificationServer implements MessageComponentInterface {
    protected $clients;
    protected $dataUpdate;

    public function __construct(DataUpdate $dataUpdate) {
        $this->clients = new \SplObjectStorage;
        $this->dataUpdate = $dataUpdate;
    }

    public function onOpen(ConnectionInterface $conn) {
        $querystring = $conn->httpRequest->getUri()->getQuery();
        parse_str($querystring, $queryParams);
        $conn->user_id = $queryParams['user_id'] ?? null;
    
        $this->clients->attach($conn);
        echo "New connection! ({$conn->resourceId}), User ID: {$conn->user_id}\n";
    
        if ($conn->user_id) {
            $notifications = $this->dataUpdate->selectNotifications($conn->user_id);
    
            foreach ($notifications as $notification) {
                echo "Notification: {$notification['id']} - {$notification['title']} - {$notification['message']} - is_received = {$notification['is_received']}\n";
    
                $message = json_encode([
                    'type' => 'notification',
                    'id' => $notification['id'],
                    'title' => $notification['title'],
                    'message' => $notification['message'],
                    'url' => $notification['url'],
                    'is_received' => $notification['is_received']
                ]);
                $conn->send($message);
    
                if ($notification['is_received'] == 0) {
                    $this->dataUpdate->markNotificationAsReceived($notification['id']);
                }
            }
        }
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg, true);

        if (isset($data['user_id'], $data['title'], $data['message'], $data['url'])) {
            // Add the notification to the database
            $notification_id = $this->dataUpdate->addNotification($data['user_id'], $data['title'], $data['message'], $data['url']);
            
            $notification = json_encode([
                'type' => 'new_notification',
                'id' => $notification_id,
                'title' => $data['title'],
                'message' => $data['message'],
                'url' => $data['url']
            ]);

            // Send the notification to connected users
            foreach ($this->clients as $client) {
                if ($client->user_id == $data['user_id']) {
                    $client->send($notification);
                    // Set is_sent to 1 after the notification is sent
                    $this->dataUpdate->markNotificationAsSent($notification_id);
                }
            }

            echo "New notification sent: {$data['title']} - {$data['message']} to user_id: {$data['user_id']}\n";
        } else {
            echo "Received incomplete message.\n";
        }
    }

    public function onClose(ConnectionInterface $conn) {
        $this->clients->detach($conn);
        echo "Connection {$conn->resourceId} has disconnected\n";
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";
        $conn->close();
    }
}

// Setting up a database connection
$dsn = 'mysql:host=localhost;dbname=dynaflux;charset=utf8';
$username = 'root';
$password = '';

try {
    $dbConnection = new PDO($dsn, $username, $password);
    $dbConnection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
    exit;
}

$dataUpdate = new DataUpdate($dbConnection);

$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new NotificationServer($dataUpdate)
        )
    ),
    8080
);

$server->run();

?>
