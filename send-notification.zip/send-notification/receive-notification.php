<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receive Notifications</title>
</head>
<body>
    <h1>Notifications</h1>
    <div id="notificationsContainer"></div>

    <script>
        const socket = new WebSocket('ws://192.168.0.6:8080');

        // Be sure to ask for permission for notifications
        function requestNotificationPermission() {
            if (Notification.permission === 'default') {
                Notification.requestPermission().then(permission => {
                    if (permission === 'granted') {
                        console.log('Notification permission granted.');
                    } else {
                        console.log('Notification permission denied.');
                    }
                });
            }
        }

        // Show desktop notification
        function showDesktopNotification(title, message, url) {
    if (Notification.permission === 'granted') {
        // Check for previous open notification
        if (!localStorage.getItem('notificationDisplayed')) {
            const notification = new Notification(title, { 
                body: message,
                icon: 'path/to/icon.png' // You can set an image path here if you want to include an icon
            });

            notification.onclick = function(event) {
                event.preventDefault(); // Prevents the notification window from opening automatically
                window.open(url, '_blank'); // Open the selected page in a new window
            };

            // Mark the notification as viewed
            localStorage.setItem('notificationDisplayed', 'true');

            // Remove the tag after a set amount of time (e.g. 10 seconds)
            setTimeout(() => {
                localStorage.removeItem('notificationDisplayed');
            }, 10000);
        }
    } else {
        console.log('Notification permission is not granted.');
    }
}



        socket.addEventListener('open', function(event) {
            console.log('Connected to the WebSocket server');
            requestNotificationPermission();
        });

        socket.addEventListener('message', function(event) {
            let receivedData;

            try {
                receivedData = JSON.parse(event.data);
            } catch (e) {
                console.error('Error parsing JSON:', e);
                return;
            }

            if (receivedData.type === 'notification') {
                displayNotification(receivedData.title, receivedData.message);
                showDesktopNotification(receivedData.title, receivedData.message, receivedData.url);
            }
        });

        function displayNotification(title, message) {
            const notificationsContainer = document.getElementById('notificationsContainer');
            const notificationDiv = document.createElement('div');

            notificationDiv.innerHTML = `<h3>${title}</h3><p>${message}</p>`;
            notificationDiv.style.border = "1px solid #000";
            notificationDiv.style.padding = "10px";
            notificationDiv.style.marginBottom = "10px";

            notificationsContainer.appendChild(notificationDiv);
        }
    </script>
</body>
</html>
