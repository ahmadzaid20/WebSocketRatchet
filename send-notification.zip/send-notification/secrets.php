<?php
// Check the existence of the function only if it doesn't already exist
if (!function_exists('checkAndReconnectDatabase')) {
    function checkAndReconnectDatabase($host, $username, $password, $database) {
        $max_retries = 3;  // Maximum number of attempts to reconnect
        $retry_count = 0;

        while ($retry_count < $max_retries) {
            $link = @mysqli_connect($host, $username, $password, $database);
            if ($link) {
                // The connection is successful
                return $link;
            }
            $retry_count++;
            sleep(1);  // Wait for a second before retrying
        }
        // Connection fails after the specified attempts
        throw new Exception('Connection error: ' . mysqli_connect_error());
    }
}

// Database connection variables from environmental variables
$host = getenv('DB_HOST') ?: 'localhost';
$username = getenv('DB_USERNAME') ?: 'root';
$password = getenv('DB_PASSWORD') ?: '';
$database = getenv('DB_DATABASE') ?: 'dynaflux';

try {
    // Trying to connect to the database
    $mysqli = checkAndReconnectDatabase($host, $username, $password, $database);
} catch (Exception $e) {
    // Dealing with a connection error
    die($e->getMessage());
}
?>
