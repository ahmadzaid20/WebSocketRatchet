<?php
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

require __DIR__ . '/vendor/autoload.php';

class DataUpdate implements MessageComponentInterface {
    protected $clients;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
    }

    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
        echo "New connection! ({$conn->resourceId}) \n";
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg, true);

        if (isset($data['action'])) {
            switch ($data['action']) {
                case 'notify':
                    if (isset($data['title']) && isset($data['message']) && isset($data['url'])) {
                        $this->broadcastNotification($data['title'], $data['message'], $data['url']);
                    }
                    break;

                // You can include other statuses such as Add, Update, Delete data here.
            }
        }
    }

    public function onClose(ConnectionInterface $conn) {
        $this->clients->detach($conn);
        echo "Connection {$conn->resourceId} has disconnected\n";
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";
        $conn->close();
    }

    protected function broadcastNotification($title, $message, $url) {
        $notification = json_encode(['type' => 'notification', 'title' => $title, 'message' => $message, 'url' => $url]);
        foreach ($this->clients as $client) {
            $client->send($notification);
        }
    }
}

$app = new DataUpdate();

$server = \Ratchet\Server\IoServer::factory(
    new \Ratchet\Http\HttpServer(
        new \Ratchet\WebSocket\WsServer(
            $app
        )
    ),
    8080
);

$server->run();
?>
